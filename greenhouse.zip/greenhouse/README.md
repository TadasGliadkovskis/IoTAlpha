# IoTAlpha
IoT module alpha CA2

to start the project: python run.py

